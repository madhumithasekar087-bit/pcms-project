"""
Public Complaint Management System (PCMS)
Flask Backend Application

BCA Final Year Project
"""

import werkzeug.serving
werkzeug.serving.BaseWSGIServer.log_startup = lambda *args, **kwargs: None

import os
import uuid
import json
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, jsonify, flash, send_from_directory
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from database import get_db, init_db

# ── App Configuration ──────────────────────────────────────────────────────
app = Flask(__name__,
            template_folder='templates',
            static_folder='static')

app.secret_key = 'pcms-secret-key-2026-bca-project'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max upload

ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
ALLOWED_VIDEO_EXTENSIONS = {'mp4', 'webm', 'avi', 'mov'}
ALLOWED_EXTENSIONS = ALLOWED_IMAGE_EXTENSIONS | ALLOWED_VIDEO_EXTENSIONS

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize Database & Cleanup Demo Complaints
init_db()
try:
    _db = get_db()
    _db.execute("DELETE FROM complaint_updates WHERE complaint_id LIKE 'PCMS-2026-DEP%'")
    _db.execute("DELETE FROM complaint_media WHERE complaint_id LIKE 'PCMS-2026-DEP%'")
    _db.execute("DELETE FROM complaints WHERE complaint_id LIKE 'PCMS-2026-DEP%'")
    _db.commit()
    _db.close()
except Exception:
    pass

# ── Department Classification Keywords ─────────────────────────────────────
DEPARTMENT_KEYWORDS = {
    'Sanitation & Solid Waste / குப்பை மற்றும் தூய்மை': [
        'garbage', 'waste', 'cleaning', 'dump', 'trash', 'sweeping', 'dustbin', 'toilet', 'mosquito', 'hygiene',
        'குப்பை', 'கழிவு', 'சுத்தம்', 'தூய்மை', 'கழிப்பறை', 'கொசு'
    ],
    'Water Supply & Drainage / குடிநீர் மற்றும் வடிகால்': [
        'water', 'pipe', 'leak', 'drainage', 'sewage', 'borewell', 'tap', 'supply', 'gutter',
        'தண்ணீர்', 'குடிநீர்', 'குழாய்', 'கசிவு', 'வடிகால்', 'சாக்கடை', 'நீர்'
    ],
    'Roads & Pavements / சாலை மற்றும் நடைபாதை': [
        'road', 'pothole', 'footpath', 'pavement', 'crack', 'speed breaker', 'barricade',
        'சாலை', 'குழி', 'நடைபாதை', 'பள்ளம்', 'வேகத்தடை', 'ரோடு'
    ],
    'Street Lights & Electricity / தெருவிளக்கு மற்றும் மின்சாரம்': [
        'electricity', 'power', 'transformer', 'streetlight', 'wire', 'voltage', 'outage', 'current', 'light',
        'மின்சாரம்', 'மின்', 'தெருவிளக்கு', 'கம்பி', 'கரண்ட்', 'விளக்கு'
    ],
    'Stray Animals Control / தெரு விலங்குகள் கட்டுப்பாடு': [
        'dog', 'stray', 'animal', 'cow', 'cattle', 'pig', 'bite',
        'நாய்', 'தெருநாய்', 'விலங்கு', 'மாடு', 'கால்நடை', 'பன்றி'
    ],
    'Public Parks & Facilities / பூங்கா மற்றும் பொது இடங்கள்': [
        'park', 'playground', 'equipment', 'bench', 'bush', 'tree', 'garden',
        'பூங்கா', 'விளையாட்டு', 'திடல்', 'செடி', 'மரம்', 'மைதானம்'
    ],
    'Local Traffic & Encroachment / போக்குவரத்து மற்றும் ஆக்கிரமிப்புகள்': [
        'traffic', 'parking', 'abandoned', 'vehicle', 'encroachment', 'shop', 'block',
        'போக்குவரத்து', 'வாகனம்', 'ஆக்கிரமிப்பு', 'கடை', 'பார்க்கிங்'
    ]
}


def classify_department(text):
    """Auto-classify complaint department based on keywords."""
    text_lower = text.lower()
    scores = {}
    for dept, keywords in DEPARTMENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text_lower)
        if score > 0:
            scores[dept] = score
    if scores:
        return max(scores, key=scores.get)
    return 'General / பொது'


def generate_complaint_id():
    """Generate unique complaint ID like PCMS-2026-XXXX."""
    year = datetime.now().year
    unique = uuid.uuid4().hex[:6].upper()
    return f"PCMS-{year}-{unique}"


def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_file_type(filename):
    """Determine if file is image or video."""
    ext = filename.rsplit('.', 1)[1].lower()
    return 'image' if ext in ALLOWED_IMAGE_EXTENSIONS else 'video'


# ── Auth Decorators ────────────────────────────────────────────────────────
def login_required(f):
    """Decorator to require login."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({'error': 'Login required / முதலில் உள்நுழையவும்'}), 401
            flash('Please login first / முதலில் உள்நுழையவும்', 'warning')
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """Decorator to require admin role."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({'error': 'Admin access required / நிர்வாகி அணுகல் தேவை'}), 403
            flash('Admin access required / நிர்வாகி அணுகல் தேவை', 'danger')
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated


# ── Page Routes ────────────────────────────────────────────────────────────
@app.route('/')
def index():
    """Landing page."""
    return render_template('index.html')


@app.route('/login')
def login_page():
    """Login/Register page."""
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('admin_page'))
        return redirect(url_for('dashboard_page'))
    return render_template('login.html')


@app.route('/dashboard')
@login_required
def dashboard_page():
    """Citizen dashboard."""
    return render_template('dashboard.html')


@app.route('/chatbot')
@login_required
def chatbot_page():
    """Chatbot complaint filing page."""
    return render_template('chatbot.html')


@app.route('/admin')
@admin_required
def admin_page():
    """Admin dashboard."""
    return render_template('admin.html')


@app.route('/complaint/<complaint_id>')
@login_required
def complaint_details_page(complaint_id):
    """Complaint details page."""
    return render_template('complaint_details.html', complaint_id=complaint_id)


@app.route('/track')
def track_page():
    """Public complaint tracking page."""
    return render_template('track.html')


# ── Auth API Routes ────────────────────────────────────────────────────────
@app.route('/api/register', methods=['POST'])
def api_register():
    """Register a new citizen."""
    data = request.get_json()
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    phone = data.get('phone', '').strip()
    password = data.get('password', '')

    if not all([name, email, phone, password]):
        return jsonify({'error': 'All fields are required / அனைத்து புலங்களும் தேவை'}), 400

    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters / கடவுச்சொல் குறைந்தது 6 எழுத்துகள் இருக்க வேண்டும்'}), 400

    db = get_db()
    try:
        db.execute(
            'INSERT INTO users (name, email, phone, password_hash) VALUES (?, ?, ?, ?)',
            (name, email, phone, generate_password_hash(password))
        )
        db.commit()
        return jsonify({'success': True, 'message': 'Registration successful! / பதிவு வெற்றிகரமாக முடிந்தது!'})
    except Exception:
        return jsonify({'error': 'Email already registered / மின்னஞ்சல் ஏற்கனவே பதிவு செய்யப்பட்டுள்ளது'}), 400
    finally:
        db.close()


@app.route('/api/login', methods=['POST'])
def api_login():
    """Login user."""
    data = request.get_json()
    email = data.get('email', '').strip()
    password = data.get('password', '')

    db = get_db()
    user = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
    db.close()

    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        session['user_name'] = user['name']
        session['role'] = user['role']
        session['email'] = user['email']
        redirect_url = url_for('admin_page') if user['role'] == 'admin' else url_for('dashboard_page')
        return jsonify({
            'success': True,
            'user': {'name': user['name'], 'role': user['role']},
            'redirect': redirect_url
        })
    return jsonify({'error': 'Invalid email or password / தவறான மின்னஞ்சல் அல்லது கடவுச்சொல்'}), 401


@app.route('/api/logout', methods=['POST'])
def api_logout():
    """Logout user."""
    session.clear()
    return jsonify({'success': True, 'redirect': url_for('index')})


@app.route('/api/user')
@login_required
def api_user():
    """Get current user info."""
    return jsonify({
        'id': session['user_id'],
        'name': session['user_name'],
        'role': session['role'],
        'email': session['email']
    })


# ── Complaint API Routes ──────────────────────────────────────────────────
@app.route('/api/complaints', methods=['POST'])
@login_required
def api_create_complaint():
    """Create a new complaint (from chatbot)."""
    data = request.get_json()
    title = data.get('title', '').strip()
    description = data.get('description', '').strip()
    category = data.get('category', '').strip()
    priority = data.get('priority', 'medium')
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    address = data.get('address', '').strip()

    if not all([title, description, category]):
        return jsonify({'error': 'Title, description and category are required'}), 400

    # Auto-classify department
    department = classify_department(f"{title} {description} {category}")

    complaint_id = generate_complaint_id()

    db = get_db()
    try:
        db.execute('''
            INSERT INTO complaints (complaint_id, user_id, title, description, category, 
                                     department, priority, latitude, longitude, address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (complaint_id, session['user_id'], title, description, category,
              department, priority, latitude, longitude, address))

        # Add initial status update
        db.execute('''
            INSERT INTO complaint_updates (complaint_id, new_status, comment, updated_by)
            VALUES (?, 'pending', 'Complaint registered / புகார் பதிவு செய்யப்பட்டது', ?)
        ''', (complaint_id, session['user_id']))

        db.commit()
        return jsonify({
            'success': True,
            'complaint_id': complaint_id,
            'department': department,
            'message': f'Complaint registered successfully! ID: {complaint_id}'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@app.route('/api/complaints/<complaint_id>/upload', methods=['POST'])
@login_required
def api_upload_media(complaint_id):
    """Upload media files for a complaint."""
    if 'files' not in request.files:
        return jsonify({'error': 'No files uploaded'}), 400

    files = request.files.getlist('files')
    uploaded = []
    db = get_db()

    for file in files:
        if file and file.filename and allowed_file(file.filename):
            ext = file.filename.rsplit('.', 1)[1].lower()
            unique_name = f"{complaint_id}_{uuid.uuid4().hex[:8]}.{ext}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
            file.save(filepath)

            file_type = get_file_type(file.filename)
            db.execute('''
                INSERT INTO complaint_media (complaint_id, filename, original_name, file_type)
                VALUES (?, ?, ?, ?)
            ''', (complaint_id, unique_name, file.filename, file_type))
            uploaded.append({'filename': unique_name, 'type': file_type})

    db.commit()
    db.close()
    return jsonify({'success': True, 'uploaded': uploaded})


@app.route('/api/complaints', methods=['GET'])
@login_required
def api_get_complaints():
    """Get complaints for current user or all (admin)."""
    db = get_db()
    status_filter = request.args.get('status', '')
    dept_filter = request.args.get('department', '')
    search = request.args.get('search', '')

    if session.get('role') == 'admin':
        query = '''SELECT c.*, u.name as user_name, u.phone as user_phone 
                   FROM complaints c JOIN users u ON c.user_id = u.id WHERE 1=1'''
        params = []
    else:
        query = '''SELECT c.*, u.name as user_name 
                   FROM complaints c JOIN users u ON c.user_id = u.id 
                   WHERE c.user_id = ?'''
        params = [session['user_id']]

    if status_filter:
        query += ' AND c.status = ?'
        params.append(status_filter)
    if dept_filter:
        query += ' AND c.department = ?'
        params.append(dept_filter)
    if search:
        query += ' AND (c.complaint_id LIKE ? OR c.title LIKE ? OR c.description LIKE ?)'
        params.extend([f'%{search}%'] * 3)

    query += ' ORDER BY c.created_at DESC'

    complaints = db.execute(query, params).fetchall()
    result = [dict(c) for c in complaints]
    db.close()
    return jsonify(result)


@app.route('/api/complaints/<complaint_id>', methods=['GET'])
def api_get_complaint(complaint_id):
    """Get single complaint details (public for tracking)."""
    db = get_db()
    complaint = db.execute(
        'SELECT c.*, u.name as user_name FROM complaints c JOIN users u ON c.user_id = u.id WHERE c.complaint_id = ?',
        (complaint_id,)
    ).fetchone()

    if not complaint:
        db.close()
        return jsonify({'error': 'Complaint not found'}), 404

    media = db.execute(
        'SELECT * FROM complaint_media WHERE complaint_id = ?', (complaint_id,)
    ).fetchall()

    updates = db.execute(
        '''SELECT cu.*, u.name as updater_name FROM complaint_updates cu 
           LEFT JOIN users u ON cu.updated_by = u.id 
           WHERE cu.complaint_id = ? ORDER BY cu.created_at ASC''',
        (complaint_id,)
    ).fetchall()

    result = dict(complaint)
    result['media'] = [dict(m) for m in media]
    result['updates'] = [dict(u) for u in updates]
    db.close()
    return jsonify(result)


@app.route('/api/complaints/<complaint_id>/status', methods=['PUT'])
@admin_required
def api_update_status(complaint_id):
    """Update complaint status (admin only)."""
    data = request.get_json()
    new_status = data.get('status')
    comment = data.get('comment', '')

    if new_status not in ['pending', 'in_progress', 'resolved', 'escalated', 'closed']:
        return jsonify({'error': 'Invalid status'}), 400

    db = get_db()
    old = db.execute('SELECT status FROM complaints WHERE complaint_id = ?', (complaint_id,)).fetchone()
    if not old:
        db.close()
        return jsonify({'error': 'Complaint not found'}), 404

    db.execute('''
        UPDATE complaints SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE complaint_id = ?
    ''', (new_status, complaint_id))

    if new_status == 'escalated':
        db.execute('''
            UPDATE complaints SET escalation_level = escalation_level + 1, 
                                  escalated_at = CURRENT_TIMESTAMP WHERE complaint_id = ?
        ''', (complaint_id,))

    db.execute('''
        INSERT INTO complaint_updates (complaint_id, old_status, new_status, comment, updated_by)
        VALUES (?, ?, ?, ?, ?)
    ''', (complaint_id, old['status'], new_status, comment, session['user_id']))

    db.commit()
    db.close()
    return jsonify({'success': True})


@app.route('/api/stats')
@login_required
def api_stats():
    """Get complaint statistics."""
    db = get_db()

    if session.get('role') == 'admin':
        where = ''
        params = []
    else:
        where = 'WHERE user_id = ?'
        params = [session['user_id']]

    total = db.execute(f'SELECT COUNT(*) as cnt FROM complaints {where}', params).fetchone()['cnt']
    pending = db.execute(f"SELECT COUNT(*) as cnt FROM complaints {where} {'AND' if where else 'WHERE'} status='pending'", params).fetchone()['cnt']
    in_progress = db.execute(f"SELECT COUNT(*) as cnt FROM complaints {where} {'AND' if where else 'WHERE'} status='in_progress'", params).fetchone()['cnt']
    resolved = db.execute(f"SELECT COUNT(*) as cnt FROM complaints {where} {'AND' if where else 'WHERE'} status='resolved'", params).fetchone()['cnt']
    escalated = db.execute(f"SELECT COUNT(*) as cnt FROM complaints {where} {'AND' if where else 'WHERE'} status='escalated'", params).fetchone()['cnt']

    # Department-wise count
    dept_stats = db.execute(f'''
        SELECT department, COUNT(*) as cnt FROM complaints {where} GROUP BY department ORDER BY cnt DESC
    ''', params).fetchall()

    # Recent 7 days daily count
    daily_stats = db.execute(f'''
        SELECT DATE(created_at) as day, COUNT(*) as cnt FROM complaints 
        {where} {'AND' if where else 'WHERE'} created_at >= DATE('now', '-7 days')
        GROUP BY DATE(created_at) ORDER BY day
    ''', params).fetchall()

    db.close()
    return jsonify({
        'total': total,
        'pending': pending,
        'in_progress': in_progress,
        'resolved': resolved,
        'escalated': escalated,
        'department_stats': [dict(d) for d in dept_stats],
        'daily_stats': [dict(d) for d in daily_stats]
    })


@app.route('/api/classify', methods=['POST'])
def api_classify():
    """Classify text into department."""
    data = request.get_json() or {}
    text = data.get('text', '')
    department = classify_department(text)
    return jsonify({'department': department})


@app.route('/api/escalate-check')
@admin_required
def api_escalate_check():
    """Check and auto-escalate complaints older than 48 hours that are still pending."""
    db = get_db()
    threshold = (datetime.now(timezone.utc) - timedelta(hours=48)).strftime('%Y-%m-%d %H:%M:%S')

    stale = db.execute('''
        SELECT complaint_id FROM complaints 
        WHERE status = 'pending' AND created_at < ? AND escalation_level = 0
    ''', (threshold,)).fetchall()

    count = 0
    for c in stale:
        db.execute('''
            UPDATE complaints SET status = 'escalated', escalation_level = 1, 
                                  escalated_at = CURRENT_TIMESTAMP,
                                  updated_at = CURRENT_TIMESTAMP
            WHERE complaint_id = ?
        ''', (c['complaint_id'],))
        db.execute('''
            INSERT INTO complaint_updates (complaint_id, old_status, new_status, comment, updated_by)
            VALUES (?, 'pending', 'escalated', 'Auto-escalated: No action for 48 hours / 48 மணி நேரம் நடவடிக்கை இல்லை - தானியங்கி முன்னிலைப்படுத்தல்', ?)
        ''', (c['complaint_id'], session['user_id']))
        count += 1

    db.commit()
    db.close()
    return jsonify({'escalated_count': count})


@app.route('/api/track/<complaint_id>')
def api_track_complaint(complaint_id):
    """Public tracking - anyone can search by complaint ID."""
    db = get_db()
    complaint = db.execute('''
        SELECT complaint_id, title, category, department, priority, status, 
               address, created_at, updated_at, escalation_level
        FROM complaints WHERE complaint_id = ?
    ''', (complaint_id,)).fetchone()

    if not complaint:
        db.close()
        return jsonify({'error': 'Complaint not found / புகார் கிடைக்கவில்லை'}), 404

    updates = db.execute('''
        SELECT new_status, comment, created_at FROM complaint_updates 
        WHERE complaint_id = ? ORDER BY created_at ASC
    ''', (complaint_id,)).fetchall()

    result = dict(complaint)
    result['updates'] = [dict(u) for u in updates]
    db.close()
    return jsonify(result)


# ── Initialize and Run ─────────────────────────────────────────────────────
if __name__ == '__main__':
    init_db()
    print("\n=== Public Complaint Management System (PCMS) ===")
    print("=" * 50)
    print("Open: http://localhost:5000")
    print("Admin Login: admin@pcms.gov.in / admin123")
    print("=" * 50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
